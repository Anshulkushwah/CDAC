package com.example.demo.controller;

import com.example.demo.model.ComplaintModel;
import com.example.demo.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ComplaintController {

    @Autowired
    private ComplaintService service;

    @GetMapping("/submit")
    public String showSubmitForm(Model model) {
        model.addAttribute("complaint", new ComplaintModel());
        return "submitComplaint";
    }

    @PostMapping("/submit")
    public String submitComplaint(@ModelAttribute ComplaintModel complaint) {
        service.saveComplaint(complaint);
        return "redirect:/view";
    }

    @GetMapping("/view")
    public String viewComplaints(Model model) {
        model.addAttribute("complaints", service.getAllComplaints());
        return "viewComplaints";
    }
}
