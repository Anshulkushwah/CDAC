package com.example.demo.service;

import com.example.demo.model.ComplaintModel;
import com.example.demo.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository repository;

    public void saveComplaint(ComplaintModel complaint) {
        repository.save(complaint);
    }

    public List<ComplaintModel> getAllComplaints() {
        return repository.findAll();
    }
}
