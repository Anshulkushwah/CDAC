const jwt = require('jsonwebtoken');

const SECRET_KEY = process.env.JWT_SECRET_KEY;

function authenticateToken(req, res, next) {
//   const token = req.cookies.token; // Retrieves the token from cookies
        token  = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MiwiZW1haWwiOiJrYXJhbjFAZ21haWwuY29tIiwiaWF0IjoxNzQ2Njk5Nzk5LCJleHAiOjE3NDY3MDMzOTl9.ygo_g8qdPemd6Qk7OFlc7G39cmH10WLrYPnf9K043Bg"


  if (!token) return res.sendStatus(401); // Unauthorized if no token

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.sendStatus(403); // Forbidden if token is invalid
    req.user = user;
    next();
  });
}

module.exports = authenticateToken;