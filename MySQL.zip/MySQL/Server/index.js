const express = require('express');
const app = express();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const pool = require('./config/db');
require("dotenv").config();
const PORT = process.env.PORT || 3000;
app.use(express.json());

const tokenVerification = require("./Middleware/token")


const SECRET_KEY = process.env.JWT_SECRET_KEY;

// --------------------------Controller--------------------------------------------

app.get('/users',async(req,res) => {
    try{
        const [row] = await pool.promise().query('SELECT * FROM users');
        if (row.length === 0) { // Check if the array is empty
            return res.json("No data found");
          }

        res.json(row);
    }catch(error){
        console.log(`We get internal server error while fetching user data : ${error}`);
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

app.post('/registration', async(req,res) => {
    const { name, email, password } = req.body;
    if(!name || !email || !password){
        return res.status(400).json({ error: 'Please fill in all fields' });
    }

    try{

        
        const [row] = await pool.promise().query('SELECT * FROM users WHERE email = ?', [email]);


        if (row.length !== 0) { // Check if the array is empty
            return res.json("User already exists");
          }

        const hashedPassword = await bcrypt.hash(password, 10);

        const [result] = await pool.promise().query(
            'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
            [name, email, hashedPassword]
        );
        res.status(201).json({ id: result.insertId, message: 'User created successfully' });
    } catch(err){
        console.log(`We get internal server error while creating user : ${err}`);
        res.status(500).json({ error: 'Failed to create user' });
    }
} )

app.post('/login', async(req,res) => {
    const { email, password } = req.body;
    if(!email || !password){
        return res.status(400).json({ error: 'Please fill in all fields' });
        }
    try{
        const [row] = await pool.promise().query('SELECT * FROM users WHERE email = ?', [email]);
            if (row.length === 0) { // Check if the array is empty
                return res.json("Invalid email or password");
                }

         // Compare hashed password
         const user = row[0];
         console.log(user.password);
            const isMatch = await bcrypt.compare(password, user.password);
            if (!isMatch) {
            return res.status(401).json({ error: 'Invalid email or password' });
            }

         const payload = {
            id: user.id,
            email: user.email,
          };
      
          
          const token = jwt.sign(payload, SECRET_KEY, { expiresIn: '1h' });


            res.json({
                 success : true,
                 message : "Login successful",
                 token : token
                });
        }catch(error){
           console.log(`We get internal server error while fetching user data : ${error}`);
          res.status(500).json({ error: 'Failed to fetch users' });
          }
                        
})

app.post('/logout',tokenVerification, (req, res) => {
    res.clearCookie('token'); // Clears the 'token' cookie
    res.status(200).json({ message: 'Logout successful' });
  });

app.put('/update-password', tokenVerification, async (req, res) => {
    
    const {email, currentPassword, newPassword } = req.body;
  
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Please provide current and new password' });
    }

    try {
      // Fetch user from DB
      const [rows] = await pool.promise().query('SELECT * FROM users WHERE email = ?', [email]);
  
      if (rows.length === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      const user = rows[0];
  
      // Check current password
      const isMatch = await bcrypt.compare(currentPassword, user.password);
      if (!isMatch) {
        return res.status(403).json({ error: 'Incorrect current password' });
      }
  
      // Hash new password and update
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      await pool.promise().query('UPDATE users SET password = ? WHERE email = ?', [hashedPassword, email]);
  
      res.json({ message: 'Password updated successfully' });
  
    } catch (error) {
      console.error('Error updating password:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
app.delete('/delete-user', tokenVerification, async (req, res) => {
    const email = req.user.email; 

    console.log("äaaaaaaaaaaaa");
  
    try {
      const [result] = await pool.promise().query('DELETE FROM users WHERE email = ?', [email]);
  
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'User not found or already deleted' });
      }
  
      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
    
  
// -------------------------Default-------------------------------

app.get('/', (req, res) => {
    res.send('<h1>Sab ok hai ji</h1>');
  });
  
app.listen(PORT, () => {
  console.log(`Server listening at http://localhost:${PORT}`);
});