USE dac_2025

select empname,
timestampdiff(year,birthdate,curdate()) as age 
from emp order by age desc;

select empcode,empname,supcode from emp
where supcode='7839'

select count(*) from emp 
where supcode=
(select empcode from emp where empname='Reddy');

select empcode,empname from emp where empcode='7839'

select empname, 
timestampdiff(year,birthdate,curdate()) as age, 
gradecode,gradelevel from emp 
order by gradecode desc,gradelevel desc;

select supcode,count(*) from emp 
group by supcode order by supcode;

select supcode,count(*) from emp 
group by supcode 
having count(*)>3 order by supcode;

select empcode,supcode from emp where supcode is null

select  
* from salary 

select empcode, 
sum(basic+allow-deduct) as pay from salary 
group by empcode 
order by empcode;

select empcode,sum(basic+allow-deduct)as pay 
from salary 
where salmonth between 
'2011-01-12' and '2012-01-12' 
group by empcode 
having sum(basic+allow-deduct)<40000 order by empcode;


select gradecode,max(basic),min(basic) 
from grade 
group by gradecode order by gradecode;

select gradecode,max(basic),min(basic) 
from grade group by gradecode 
having min(basic)<4000 
order by gradecode;
--- list name of staff reporting to each supervisor-----

select e.empcode,e.empname,s.empcode,s.empname 
from emp e inner join emp s 
on e.supcode=s.empcode;


select empcode,empname,salary.basic 
from emp 
inner join salary using (empcode);

select empcode,empname,basic 
from emp natural join salary;

select * from grade order by gradecode

select e.empname,d.deptcode from 
emp e right outer join dept d 
on e.deptcode = d.deptcode;

select supcode,count(*) from emp 
where gradecode < 10 
and supcode in 
(select supcode from emp 
group by supcode having count(*)>3) group by supcode;

select empcode,empname,deptcode 
from emp
where not exists 
(select * from history 
where history.empcode=emp.empcode 
and changedate>= '1990-01-01');

select * from history 
where changedate>= '1990-01-01'

select empcode,empname,deptcode,gradecode,gradelevel 
from emp where empcode in 
(select empcode from history 
where gradecode >= 'GC12'  
AND CHANGEDATE >='1981-04-22'
);

select max(basic+allow-deduct)as 
takehome from salary 
where (basic+allow-deduct) 
not in (select max(basic+allow-deduct) from salary);



select (basic+allow-deduct)as takehome 
from salary ORDER BY takehome desc

SELECT DISTINCT basic + allow - deduct AS takehome
FROM salary
ORDER BY takehome DESC
LIMIT 1 OFFSET 2;



select * from salary order by salmonth desc
insert into salary 
select 
empcode,
current_date,
basicpay,basicpay*1.5,basicpay*0.3 
from emp;





select * from salary
SELECT * FROM HISTORY WHERE GRADECODE='GC12' AND CHANGEDATE >='1981-04-22' 
order by changedate