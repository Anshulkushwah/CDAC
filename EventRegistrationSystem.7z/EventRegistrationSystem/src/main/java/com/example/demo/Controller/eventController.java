package com.example.demo.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.Model.userModel;
import com.example.demo.Services.userService;

import org.springframework.web.bind.annotation.PostMapping;




@Controller
public class eventController {
	@Autowired
	private userService user;
	
	@GetMapping("/")
	public String Alldata(Model model){
		model.addAttribute("users",user.findAll());
		return "index";
	}
	
	@GetMapping("/edit/{id}")
	public String databyId (Model model, @PathVariable int id){
		Optional<userModel> modelData = user.findById(id);
		if(modelData.isPresent()) {
			model.addAttribute("userdata", modelData.get());
			 return "edit";
		}
		else {
			
			return "redirect:/?error=notfound";
			
		}
	}
	
	@PostMapping("/update")
	public String updateData(@ModelAttribute userModel data) {
		user.create(data);
		return "redirect:/";
	}
	
	@GetMapping("/add")
	public String RegisterationForm(Model model ){
		model.addAttribute("user",new userModel());
		return "add";
	}
	
	@PostMapping("/register")
	public String Register(@ModelAttribute userModel data) {
	    user.create(data);
	    return "redirect:/"; 
	}

	@GetMapping("/delete/{id}")
	public String postMethodName(@PathVariable int id) {
		user.deleteById(id);
		
		return "redirect:/";
	}
	
	
	
	
}
