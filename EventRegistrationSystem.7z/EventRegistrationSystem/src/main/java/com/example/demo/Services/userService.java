package com.example.demo.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.userModel;
import com.example.demo.Repository.userRepository;


@Service
public class userService {

	@Autowired
	private userRepository user;
	
	public List<userModel>findAll(){
		return user.findAll();
	}
	
	public Optional<userModel> findById(int id) {
		return user.findById(id);
	}
	
	public void deleteById(int id) {
		user.deleteById(id);
		System.out.println("--------------------------------------");
		System.out.print("-------User delete succesfully----------");
		System.out.println("--------------------------------------");
	}
	
	public void create(userModel userData) {
		user.save(userData);
		System.out.println("--------------------------------------");
		System.out.print("-------User update succesfully----------");
		System.out.println("--------------------------------------");
	}
	
	
}
