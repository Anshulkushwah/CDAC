const jwt = require('jsonwebtoken');

const SECRET_KEY = process.env.JWT_SECRET_KEY;

function authenticateToken(req, res, next) {
//   const token = req.cookies.token; // Retrieves the token from cookies
        token  = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MywiZW1haWwiOiJtc2dAZ21haWwuY29tIiwiaWF0IjoxNzQ2Njk2OTU5LCJleHAiOjE3NDY3MDA1NTl9.k80tizRoYDgpfHfjVidBVrzCR6GiMdf_i04US76bSV0"


  if (!token) return res.sendStatus(401); // Unauthorized if no token

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.sendStatus(403); // Forbidden if token is invalid
    req.user = user;
    next();
  });
}

module.exports = authenticateToken;